<?php $__env->startSection('content'); ?>
    <h1>Movies List</h1>
    <hr>

    <table class = "table table-striped table-bordered">
        <thead>
        <tr>
            
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a style= "font-weight: bold ;"href="/movies/<?php echo e($movie->id); ?>"><?php echo e($movie->title); ?></a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($movies->links()); ?>

        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>