<?php $__env->startSection('content'); ?>
        <h1>Movies List</h1>
        <hr>

        <table class = "table table-striped table-bordered">
                <thead>
                    <tr>
                        <th><?php echo e($movie->title); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($name); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
        </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>