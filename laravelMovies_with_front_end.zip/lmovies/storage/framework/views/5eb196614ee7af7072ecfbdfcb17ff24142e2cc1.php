<?php $__env->startSection('content'); ?>
    <div class = "row">
        <h3>Filter: </h3>
        <div class = "btn-group">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button" class="btn btn-primary"><a style= "color: white;"href="/movies?category_id=<?php echo e($category->id); ?>"><?php echo e($category->name); ?></a></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <hr>
    <div class = "row">
        <h3>Sort By: </h3>
        <div class = "dropdown offset-md-1">
            <h3>Popularity</h3>
            <button type="button" class="btn btn-primary"><a style= "color: white;"href="/movies?popular=asc">Ascending</a></button>
            <button type="button" class="btn btn-primary"><a style= "color: white;"href="/movies?popular=desc">Descending</a></button>
            <h3>Ratings</h3>
            <button type="button" class="btn btn-primary"><a style= "color: white;"href="/movies?rated=asc">Ascending</a></button>
            <button type="button" class="btn btn-primary"><a style= "color: white;"href="/movies?rated=desc">Descending</a></button>
        </div>
    </div>
    <hr>
    <h1>Movies List</h1>
    <hr>

    <table class = "table table-striped table-bordered">
        <thead>
        <tr>
            <th>Movies</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a style= "font-weight: bold ;"href="/movies/<?php echo e($movie->id); ?>"><?php echo e($movie->title); ?></a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($movies->links()); ?>

        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>