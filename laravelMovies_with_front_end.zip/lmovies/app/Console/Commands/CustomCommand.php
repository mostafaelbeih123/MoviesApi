<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class CustomCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'custom:command';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Seeding the database with the latest movies';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $genres = file_get_contents('https://api.themoviedb.org/3/genre/movie/list?api_key=92670c6df87c32044ce028edec3e8501&language=en-US
');
        $genres = json_decode($genres,true);
        $genres_data = $genres["genres"];
        for($i=0;$i<count($genres_data);$i++){
            $data = $genres_data[$i];
            $id = $data["id"];
            $name = $data["name"];
            DB::table('categories')->insert([
                'id' => $id,
                'title' => $name,
            ]);
        }



//        $address = 'https://api.themoviedb.org/3/movie/now_playing?api_key=92670c6df87c32044ce028edec3e8501&language=en-US&page=2';
        for ($x=1;$x<5;$x++){
            $address = 'https://api.themoviedb.org/3/movie/now_playing?api_key=92670c6df87c32044ce028edec3e8501&language=en-US&page='. $x;
            $data = file_get_contents($address);
            $data = json_decode($data,true);
            $movies = $data["results"];


            for($i=0;$i<count($movies);$i++){
                $movie_data = $movies[$i];
                $movie_title = $movie_data["title"];
                $movie_id = $movie_data["id"];
                $movie_vote = $movie_data["vote_average"];
                $movie_popularity = $movie_data["popularity"];
                $genres = $movie_data["genre_ids"];
                DB::table('movies')->insert([
                    'id' => $movie_id,
                    'title' => $movie_title,
                    'vote_average' => $movie_vote,
                    'popularity' => $movie_popularity,
                ]);


                for($j=0;$j<count($genres);$j++){
                    DB::table('views')->insert([
                        'id' => $movie_data["id"],
                        'genre_id' => $genres[$j],
                    ]);
                }
            }
        }
    }
}
