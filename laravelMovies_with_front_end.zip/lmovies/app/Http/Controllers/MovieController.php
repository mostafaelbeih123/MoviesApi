<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Movie;
use App\View;
use App\Category;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\LengthAwarePaginator;

class MovieController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(request()->has('popular') || request()->has('rated')){
            if(request()->has('popular')){
                $key = request('popular');
                if($key == 'desc'){
                    $movies = DB::table('movies')->orderBy('movies.popularity','desc')->paginate(10)
                        ->appends('popular',request('popular'));
                }

                else if($key == 'asc'){
                    $movies = DB::table('movies')->orderBy('movies.popularity','asc')->paginate(10)
                        ->appends('popular',request('popular'));
                }
            }
            else if(request()->has('rated')){
                $key = request('rated');
                if($key == 'desc'){
                    $movies = DB::table('movies')->orderBy('movies.vote_average','desc')->paginate(10)
                        ->appends('rated',request('rated'));
                }
                else if($key == 'asc'){
                    $movies = DB::table('movies')->orderBy('movies.vote_average','asc')->paginate(10)
                        ->appends('rated',request('rated'));
                }
            }
            return view('movies.filter')->with('key',$key)->with('movies',$movies);
        }

        else if(request()->has('category_id')){
            $category_id = request('category_id');
            $movies = DB::table('movies')
                ->select('movies.id','movies.title')
                ->join('views','movies.id','=','views.id')
                ->where('views.genre_id','=',$category_id)
                ->distinct()
                ->paginate(10)
                ->appends('category_id',request('category_id'));
            $categories = DB::table('categories')->get();
            return view('movies.category')->with('movies',$movies)->with('categories',$categories);
        }


        else {
            $movies = DB::table('movies')->paginate(10);
            $categories = DB::table('categories')->get();
            return view('movies.index')->with('movies',$movies)->with('categories',$categories);
        }
    }

    public function test(){

        $movies = DB::table('movies')
                            ->select('movies.id','movies.title')
                            ->join('views','movies.id','=','views.id')
                            ->where('views.genre_id','=',28)
                            ->distinct()
                            ->get();

        return view('movies.2')->with('movies',$movies);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $request
     * @return \Illuminate\Http\Response
     */

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $movie = Movie::find($id);
        $genre_list = View::where('id','=',$movie->id)->get();
        $names = array();
        foreach ($genre_list as $genre){
            $genre_name = Category::where('id','=',$genre->genre_id)->first();
            $name = $genre_name->name;
            array_push($names,$name);
        }
        return view('movies.movie')->with('movie',$movie)->with('names',$names)->with('genre_list',$genre_list);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
