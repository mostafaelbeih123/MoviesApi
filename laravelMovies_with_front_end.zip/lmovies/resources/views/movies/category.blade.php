@extends('layouts.main')
@section('content')
    <div class = "row">
        <h3>Filter: </h3>
        <div class = "btn-group">
            @foreach($categories as $category)
                <button type="button" class="btn btn-primary"><a style= "color: white;"href="/movies?category_id={{$category->id}}">{{$category->name}}</a></button>
            @endforeach
        </div>
    </div>
    <hr>
    <div class = "row">
        <h3>Sort By: </h3>
        <div class = "dropdown offset-md-1">
            <h3>Popularity</h3>
            <button type="button" class="btn btn-primary"><a style= "color: white;"href="/movies?popular=asc">Ascending</a></button>
            <button type="button" class="btn btn-primary"><a style= "color: white;"href="/movies?popular=desc">Descending</a></button>
            <h3>Ratings</h3>
            <button type="button" class="btn btn-primary"><a style= "color: white;"href="/movies?rated=asc">Ascending</a></button>
            <button type="button" class="btn btn-primary"><a style= "color: white;"href="/movies?rated=desc">Descending</a></button>
        </div>
    </div>
    <hr>
    <h1>Movies List</h1>
    <hr>

    <table class = "table table-striped table-bordered">
        <thead>
        <tr>
            <th>Movies</th>
        </tr>
        </thead>
        <tbody>
        @foreach($movies as $movie)
            <tr>
                <td><a style= "font-weight: bold ;"href="/movies/{{$movie->id}}">{{$movie->title}}</a></td>
            </tr>
        @endforeach
        {{$movies->links()}}
        </tbody>
    </table>
@endsection
