@extends('layouts.main')
@section('content')
    <h1>Movies List</h1>
    <hr>

    <table class = "table table-striped table-bordered">
        <thead>
        <tr>
            {{--<th>{{$title->title}}</th>--}}
        </tr>
        </thead>
        <tbody>
        @foreach($movies as $movie)
            <tr>
                <td><a style= "font-weight: bold ;"href="/movies/{{$movie->id}}">{{$movie->title}}</a></td>
            </tr>
        @endforeach
        {{$movies->links()}}
        </tbody>
    </table>
{{--    {{$filtered_movies->links()}}--}}
@endsection
