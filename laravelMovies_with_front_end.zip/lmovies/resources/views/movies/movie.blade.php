@extends('layouts.main')
@section('content')
        <h1>Movies List</h1>
        <hr>

        <table class = "table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>{{$movie->title}}</th>
                    </tr>
                </thead>
                <tbody>
                @foreach($names as $name)
                    <tr>
                        <td>{{$name}}</td>
                    </tr>
                @endforeach
                </tbody>
        </table>
@endsection
