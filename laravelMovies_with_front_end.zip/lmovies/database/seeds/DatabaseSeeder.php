<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $genres = file_get_contents('https://api.themoviedb.org/3/genre/movie/list?api_key=92670c6df87c32044ce028edec3e8501&language=en-US
');
        $genres = json_decode($genres,true);
        $genres_data = $genres["genres"];
        for($i=0;$i<count($genres_data);$i++){
            $data = $genres_data[$i];
            $id = $data["id"];
            $name = $data["name"];
            DB::table('categories')->insert([
                'id' => $id,
                'name' => $name,
            ]);
        }



//        $address = 'https://api.themoviedb.org/3/movie/now_playing?api_key=92670c6df87c32044ce028edec3e8501&language=en-US&page=2';
        for ($x=1;$x<6;$x++){
            $address = 'https://api.themoviedb.org/3/movie/now_playing?api_key=92670c6df87c32044ce028edec3e8501&language=en-US&page='. $x;
            $data = file_get_contents($address);
            $data = json_decode($data,true);
            $movies = $data["results"];


            for($i=0;$i<count($movies);$i++){
                $movie_data = $movies[$i];
                $movie_title = $movie_data["title"];
                $movie_id = $movie_data["id"];
                $movie_vote = $movie_data["vote_average"];
                $movie_popularity = $movie_data["popularity"];
                $genres = $movie_data["genre_ids"];
                DB::table('movies')->insert([
                    'id' => $movie_id,
                    'title' => $movie_title,
                    'vote_average' => $movie_vote,
                    'popularity' => $movie_popularity,
                ]);


                for($j=0;$j<count($genres);$j++){
                    DB::table('views')->insert([
                        'id' => $movie_data["id"],
                        'genre_id' => $genres[$j],
                    ]);
                }
            }
        }


    }
}
