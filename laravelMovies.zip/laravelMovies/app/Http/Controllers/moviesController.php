<?php

namespace App\Http\Controllers;

use App\Http\Resources\CategoryResource;
use Illuminate\Http\Request;
use App\Movie;
use Illuminate\Support\Facades\DB;
use App\Http\Resources\MovieResource;

class moviesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(request()->has('popular') || request()->has('rated')){
            if(request()->has('popular')){
                $key = request('popular');
                if($key == 'desc'){
                    $movies = DB::table('movies')->orderBy('movies.popularity','desc')->paginate(10)
                        ->appends('popular',request('popular'));
                }

                else if($key == 'asc'){
                    $movies = DB::table('movies')->orderBy('movies.popularity','asc')->paginate(10)
                        ->appends('popular',request('popular'));
                }
            }
            else if(request()->has('rated')){
                $key = request('rated');
                if($key == 'desc'){
                    $movies = DB::table('movies')->orderBy('movies.vote_average','desc')->paginate(10)
                        ->appends('rated',request('rated'));
                }
                else if($key == 'asc'){
                    $movies = DB::table('movies')->orderBy('movies.vote_average','asc')->paginate(10)
                        ->appends('rated',request('rated'));
                }
            }
            return new MovieResource($movies);
        }
        else if(request()->has('category_id')){
            $category_id = request('category_id');
            $movies = DB::table('movies')
                ->select('movies.*')
                ->join('views','movies.id','=','views.id')
                ->where('views.genre_id','=',$category_id)
                ->distinct()
                ->paginate(10)
                ->appends('category_id',request('category_id'));
            return new MovieResource($movies);
        }
        $movies = Movie::paginate(10);
        return MovieResource::collection($movies);
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $movie = DB::table('movies')
                    ->select('movies.*','categories.name as category')
                    ->join('views','movies.id','=','views.id')
                    ->join('categories','views.genre_id','=','categories.id')
                    ->where('movies.id','=',$id)->distinct()->get();


        return new MovieResource($movie);
    }
}
